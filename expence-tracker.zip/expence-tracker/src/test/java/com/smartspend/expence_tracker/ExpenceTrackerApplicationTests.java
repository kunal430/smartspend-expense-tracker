package com.smartspend.expence_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenceTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
